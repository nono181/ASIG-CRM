<?php

return [
    'password' => 'Parola trebuie sa conțină cel putin sase caractere si sa se potriveasca cu confirmarea',
    'reset'    => 'Parola a fost resetată!',
    'sent'     => 'Voam trimis un e-mail cu legatura de resetare a parolei',
    'token'    => 'Tokenul pentru resetarea parolei este invalid',
    'user'     => 'Nu am găsit un utilizator cu aceasta adresa de e-mail',
    'updated'  => 'Parola a fost schimbată!',

];
