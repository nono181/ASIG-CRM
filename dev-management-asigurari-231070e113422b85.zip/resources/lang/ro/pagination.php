<?php

return [
    'previous' => '&laquo; Anteriorul',
    'next'     => 'Urmatorul &raquo;',

];
