<?php

return [
    'site_title' => 'Management Asigurari',

];
