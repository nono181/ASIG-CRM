<?php

return [
    'failed'   => 'Aceste credențiale nu corespund cu înregistrările noastre.',
    'password' => 'Parola furnizată este incorectă.',
    'throttle' => 'Prea multe încercări de conectare. Încercați din nou peste :seconds secunde.',

];
